unsigned char IO_BYTE_READ(unsigned short port);
void IO_BYTE_WRITE(unsigned short port, unsigned char data);
