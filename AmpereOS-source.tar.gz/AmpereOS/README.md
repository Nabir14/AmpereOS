# AmpereOS
AmpereOS is an open source operating system.

![ampereos_icon](https://github.com/Nabir14/AmpereOS/blob/main/aos_icon.svg)

**Development Chart:**
- Bootloader (✓)
- Kernel (under_developement)
- Main (X)
